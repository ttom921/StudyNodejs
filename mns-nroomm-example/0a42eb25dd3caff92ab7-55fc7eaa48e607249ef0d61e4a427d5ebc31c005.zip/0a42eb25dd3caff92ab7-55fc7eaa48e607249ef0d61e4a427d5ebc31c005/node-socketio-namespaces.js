/////////////// server code index.js

var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
  res.sendfile('index.html');
})

//default namespace
io.on('connection', function(socket) {
  console.log('a user connected');
  
  socket.on('disconnect', function(){
    console.log('user disconnected');
  });

  socket.on('chat message', function(msg){
    console.log(msg);
    io.emit('chat message', msg);
  });
});


//printer namespace
var nsPrinters = io.of("/A4D90C-printers");
nsPrinters.on('connection', function(socket) {
  socket.on('connect', function(msg){
    //console.log("PRN: connect: ",socket.id);
  });
		
  socket.on('getInfo', function(msg){
    socket.emit("info","response for printer.getInfo("+msg+")");
  });

  socket.on('disconnect', function(){
    //nsp.emit("chat message", name+": disconnection");
  });
});

//network namespace
var nsNetwork = io.of("/A4D90C-network");
nsNetwork.on('connection', function(socket) {
  socket.on('connect', function(msg){
    //console.log("PRN: connect: ",socket.id);
  });
    
  socket.on('getInfo', function(msg, cb){
    console.log("test");
    //socket.emit("info","response for network.getInfo("+msg+")");
    cb("callback response for network.getInfo("+msg+")");
  });

  socket.on('disconnect', function(){
    //nsp.emit("chat message", name+": disconnection");
  });
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});


/////////////// client code index.html

/*
<!doctype html>
<html>
  <head>
    <title>Socket.IO chat</title>
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body { font: 13px Helvetica, Arial; }
      form { background: #000; padding: 3px; position: fixed; bottom: 0; width: 100%; }
      form input { border: 0; padding: 10px; width: 90%; margin-right: .5%; }
      form button { width: 9%; background: rgb(130, 224, 255); border: none; padding: 10px; }
      #messages { list-style-type: none; margin: 0; padding: 0; }
      #messages li { padding: 5px 10px; }
      #messages li:nth-child(odd) { background: #eee; }
    </style>
  </head>
  <body>
    <button id="printers_getInfo">printers_getInfo</button>
    <button id="network_getInfo">network_getInfo</button>
    <ul id="messages"></ul>
    <form action="">
      <input id="m" autocomplete="off" /><button>Send</button>
    </form>
  </body>
  <script src="socket.io/socket.io.js"></script>
  <script src="http://code.jquery.com/jquery-1.11.1.js"></script>
  <script>
    var root = io.connect("http://XXXXXXXXX:3000");
    var printers = io.connect("http://XXXXXXXXX:3000/A4D90C-printers");
    var network = io.connect("http://XXXXXXXXX:3000/A4D90C-network");

    $('#printers_getInfo').click(function() {
      printers.emit('getInfo','');
    });
    
    printers.on('info', function(msg){
      $('#messages').append($('<li>').text("printer:"+msg));
    });

    $('#network_getInfo').click(function() {
      network.emit('getInfo','', function(msg) {
        $('#messages').append($('<li>').text("network:"+msg));
      });
    });
    
    // network.on('info', function(msg){
    //   $('#messages').append($('<li>').text("network:"+msg));
    // });  


    //CHAT

    $('form').submit(function(){
      root.emit('chat message', $('#m').val());
      $('#m').val('');
      return false;
    });

    root.on('chat message', function(msg){
      $('#messages').append($('<li>').text(msg));
    });  

</script>
</html>
*/
